const express = require("express");
const { pool } = require("../config/database");
const { checkAuth } = require("../middleware/auth");

const router = express.Router();

router.get("/user", checkAuth, async (req, res) => {
  try {
    const [users] = await pool.query(
      "SELECT id, email FROM users WHERE id = ?",
      [req.session.userId]
    );
    if (users.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "User not found." });
    }

    const user = users[0];
    res.json({
      success: true,
      email: user.email,
    });
  } catch (err) {
    console.error("Error retrieving user:", err);
    res.status(500).json({ success: false, message: "Server error." });
  }
});

router.get("/check-session", checkAuth, async (req, res) => {
  try {
    const [users] = await pool.query(
      "SELECT id, email FROM users WHERE id = ?",
      [req.session.userId]
    );
    if (users.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "User not found." });
    }

    const user = users[0];
    res.json({ success: true, userId: user.id, email: user.email });
  } catch (err) {
    console.error("Error checking session:", err);
    res.status(500).json({ success: false, message: "Server error." });
  }
});

router.get("/get-profile", checkAuth, async (req, res) => {
  try {
    const [users] = await pool.query("SELECT id FROM users WHERE id = ?", [
      req.session.userId,
    ]);
    if (users.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "User not found." });
    }

    const [profiles] = await pool.query(
      `SELECT first_name, middle_name, last_name, email, phone_number, phone_verified,
              DATE_FORMAT(date_of_birth, '%Y-%m-%d') AS date_of_birth, 
              gender, address_line_1, address_line_2, city, state, zip_code, country, profile_image
       FROM profile WHERE user_id = ?`,
      [req.session.userId]
    );

    if (profiles.length === 0) {
      return res.json({ success: true, profile: {} });
    }

    res.json({ success: true, profile: profiles[0] });
  } catch (err) {
    console.error("Error fetching profile:", err);
    res.status(500).json({ success: false, message: "Server error." });
  }
});

router.post("/popup/submit", checkAuth, async (req, res) => {
  const { responses } = req.body;
  const userId = req.session.userId;

  if (!responses || typeof responses !== "object") {
    return res
      .status(400)
      .json({ success: false, message: "Invalid or missing responses data." });
  }

  try {
    const [users] = await pool.query("SELECT id FROM users WHERE id = ?", [
      userId,
    ]);
    if (users.length === 0) {
      return res
        .status(404)
        .json({ success: false, message: "User not found." });
    }

    if (responses.personalInfo) {
      const { fullName, gender, dateOfBirth, country } = responses.personalInfo;

      let first_name = fullName;
      let last_name = null;
      if (fullName && fullName.includes(" ")) {
        const nameParts = fullName.split(" ");
        first_name = nameParts[0];
        last_name = nameParts.slice(1).join(" ");
      }

      await pool.query(
        `INSERT INTO profile (
          user_id, first_name, last_name, gender, date_of_birth, country
        ) VALUES (?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
          first_name = VALUES(first_name),
          last_name = VALUES(last_name),
          gender = VALUES(gender),
          date_of_birth = VALUES(date_of_birth),
          country = VALUES(country)`,
        [
          userId,
          first_name || null,
          last_name || null,
          gender || null,
          dateOfBirth || null,
          country || null,
        ]
      );
    }

    const responsesJson = JSON.stringify(responses);

    await pool.query(
      `
      INSERT INTO user_popup_responses (user_id, responses) 
      VALUES (?, ?) 
      ON DUPLICATE KEY UPDATE responses = ?
      `,
      [userId, responsesJson, responsesJson]
    );

    res.json({ success: true, message: "User responses saved successfully." });
  } catch (err) {
    console.error("Error saving popup responses:", err);
    res.status(500).json({ success: false, message: "Server error." });
  }
});

router.post("/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ success: false, message: "Logout failed" });
    }
    res.clearCookie("connect.sid");
    res.json({ success: true });
  });
});

module.exports = router;